 define([
	'jquery',
	'underscore',
	'backbone',
 	], function($, _, Backbone) {
        var SettingsModel = Backbone.Model.extend({
            
          });
       return SettingsModel;

});    