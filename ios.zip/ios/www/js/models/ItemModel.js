 define([
	'jquery',
	'underscore',
	'backbone',
 	], function($, _, Backbone) {
        var ItemModel = Backbone.Model.extend({
            defaults:{
            firstname:"",
            surname:"",
            email:"",
            address:"",
            postcode:"",
            city:""    
            },
            
          });
       return ItemModel;

});    