define([
  'jQuery',
  'Underscore',
  'Backbone'
], function($, _, Backbone){

  return {};
});
