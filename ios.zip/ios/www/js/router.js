// Filename: router.js
define([
    'jquery',
    'underscore',
    'backbone',
    'global/Helper',
    'global/BaseRouter',
    'views/LoginView',
    'views/TopLevelView',
    'views/SubLevelView',
    'views/MapsView',
     'views/PersonView'
], function($, _, Backbone,Helper,BaseRouter,LoginView,TopLevelView,SubLevelView,MapsView,PersonView) {
    
    var AppRouter = BaseRouter.extend({
        
        
        routes: { 
            "": 'login',
            "login": 'login',
            "toplevel":"metro",
            "sublevel/:id":"subMetro",
            "maps": "maps",
            "person/:id":"person"
        },
        
        
        login : function(){
            
            var self = this;
            Helper.showPage('#login', function(){
                if( self.viewManager.getView('login')){
                    var view =  self.viewManager.getView('login');
                }else{
                    var view = self.viewManager.addView('login' ,new LoginView());  
                }
                
            });   
        },
        metro : function(){
            var self = this;
            Helper.showPage('#toplevel', function(){
                if( self.viewManager.getView('metro')){
                    var view =  self.viewManager.getView('toplevel');
                }else{
                    var view = self.viewManager.addView('toplevel' ,new TopLevelView());  
                }
                
            }); 
        },
        subMetro : function(id){
               var self = this;
             Helper.showPage('#sublevel', function(){
             var view = self.viewManager.addView('sublevel' ,new SubLevelView({"id":id}));  
                   
            }); 
        },    
        maps : function(){
            var self = this;
            Helper.showPage('#maps', function(){
            var view = self.viewManager.addView('maps' ,new MapsView());  
            view.updateMap();    
            }); 
        },   
        person : function(id){
            var self = this;
            Helper.showPage('#person', function(){
             var view = self.viewManager.addView('person' ,new PersonView({"id":id}));  
                  
            }); 
        }, 
    });
    return AppRouter;
});
