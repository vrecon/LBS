define([
    'jquery',
    'underscore',
    'backbone',
    'global/Helper',       
    'text!templates/toplevel.html',
], function($, _, Backbone,Helper,template) {
    
    var TopLevelView = Backbone.View.extend({
        
        template: _.template(template),
        identifier: 'toplevel',
        events:{
            "click .boxInner":"subLevel",
        },
        settings:"",
        
        subLevel:function (e) {
        e.preventDefault();
        e.stopPropagation();
        var hash = e.target.id;
        Helper.go("#sublevel/"+hash);
        
    },
                                         
    initialize: function () {
        this.settings = JSON.parse(window.localStorage.getItem("settings"));    
        Helper.setPageContent('#toplevel-content', this.$el); 
        this.render();    
    },
        render: function () {
            var topLevels = this.getTopLevels();
            this.setElement($('#toplevel-content'));
            this.$el.html(this.template({"topLevels":topLevels}));
            return this;    
        },
        getTopLevels : function(){
                var topLevels = [];
                for (var key in this.settings) {
                    topLevels.push(key);
                }
            return topLevels;
            },
                
});           
    return TopLevelView;
    });    