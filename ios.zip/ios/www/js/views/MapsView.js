define([
    'jquery',
    'underscore',
    'backbone',
    'gmap',
    'global/Helper',
    'collections/Collection',
    'text!templates/maps.html'
], function($, _, Backbone, googleMap,Helper,mapCollection,mapTemplate){
    
    var MapsView = Backbone.View.extend({
        template:_.template(mapTemplate),
        identifier: 'maps',
        model:null,
        
        events:{
            "click .icon-menu":"menu",
            "click #sector":"popupSectors",    
            "click #icon_more":"person"
        },    
        
        menu : function(){
            Helper.go("#toplevel");
        },
        
        person : function(){
            Helper.go("#person/"+this.model.get("id"));
        },
        
        popupSectors : function(){
            $("#popUpDiv").show();
        },    
        
        initialize: function(){
            Helper.setPageContent('#maps-content', this.$el); 
            
            this.render();
        },
        
        render: function(){
            this.setElement($('#maps-content'));    
            this.renderedView = this.template();
            this.$el.html(this.renderedView);
            var height = window.innerHeight ;
            var width = window.innerWidth;
            $('#map-canvas').height(height);
            $('#map-canvas').width(width);
        },
        
        updateMap : function(){
             var self = this;
            setTimeout(function(){
                function geoloc(success, fail){
                    var is_echo = false;
                    if(navigator && navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(
                            function(pos) {
                                if (is_echo){ return; }
                                is_echo = true;
                                success(pos.coords.latitude,pos.coords.longitude);
                            }, 
                            function() {
                                if (is_echo){ return; }
                                is_echo = true;
                                fail();
                            }
                        );
                    } else {
                        fail();
                    }
                }
                
                function success(lat, lng){
                    var latlng = new google.maps.LatLng(lat, lng); 
                    var mapOptions = {
                        zoom: 10,
                        center: latlng,
                        disableDefaultUI: true,
                        mapTypeId: google.maps.MapTypeId.ROADMAP
                    };
                    var map = new google.maps.Map(document.getElementById("map-canvas"),
                                                  mapOptions);   
                    // Create marker 
                    
                    self.collection = new mapCollection();
                   
                    
                    
                    self.collection.fetch({success: function(){
                        
                        _.each(self.collection.models,function(coords){
                            var loc = new google.maps.LatLng(coords.get("lat"), coords.get("lng"));
                            var marker = new google.maps.Marker({
                                position: loc,
                                map: map,
                                                                title:coords.get("id")
                            });
                            google.maps.event.addListener(marker, 'click', function() {
                                map.setZoom(15);
                                var height = window.innerHeight ;
                                 $('#map-canvas').height(height*0.75);
                                $('#under_map').show();
                                self.model =   self.collection.get(marker.title);
                                $("#bscname").html(self.model.get("name"));
                                $("#bscorganisation").html(self.model.get("organisation"));
                                map.setCenter(marker.getPosition());
                            });     
                            
                        });
                        self.collection.bind("reset", function(){self.render();}, self);
                    }});
                    
                    
                    google.maps.event.trigger(map, "resize");
                    map.setZoom( map.getZoom() );
                } 
                function fail(){
                    alert("failed");
                }
                
                geoloc(success, fail);
                
                
                
            }, 100);   
            
            
            
        }    
        
    });
    return MapsView;
});