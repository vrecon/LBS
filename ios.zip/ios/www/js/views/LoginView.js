define([
'jquery',
'underscore',
'backbone',
'global/Helper',
'global/BaseView',    
'text!templates/login.html',
"i18n!nls/settings",
"models/SettingsModel"    
], function($, _, Backbone,Helper,BaseView,template,settings,SettingsModel) {

var LoginView = BaseView.extend({

    template: _.template(template),
    identifier: 'login',
    events:{
      'submit': 'login',
                                'focus input' : 'focus',
       'keypress input[type=password]': 'processKey'   
    },

    login:function (event) {
        $(".password").blur();
        Helper.go("#toplevel");
    },
    initialize: function () {
     this.setUserSettings();    
     Helper.setPageContent('#login-content', this.$el);    
     this.render();        
    },
            focus: function(){
            e.preventDefault(); e.stopPropagation();
                                

                                },
    processKey: function(e) { 
        if (e.keyCode != 13) return;
        this.login();
    },
    render: function () {
        this.setElement($('#login-content'));
        this.renderedView = this.template();
        this.$el.html(this.renderedView);
        return this.renderedView;    
    },

    setUserSettings : function(){
      var model = new SettingsModel(settings);        
      window.localStorage.setItem("settings",JSON.stringify(model));  
    },
    });           
    return LoginView;
});    