    define([
    'jquery',
    'underscore',
    'backbone',
    'global/Helper',       
    'text!templates/person.html',
    ], function($, _, Backbone,Helper,template) {
    
    var PersonView = Backbone.View.extend({
    
        template: _.template(template),
        identifier: 'person',
         settings:[],
        events:{
            "click #icon_back":"back",
            "click #icon_twitter": "twitter",
            "click #icon_linkedin":"linkedin"
        },
    
        back : function(){
        Helper.go("#maps");
        },    
        
        twitter:function(){
        
        },
        
        linkedin : function(){
    
        },

        initialize: function () { 
            Helper.setPageContent('#person-content', this.$el); 
            this.render();    
        },
        render: function () {
            this.setElement($('#person-content'));
            this.$el.html(this.template());
                 var height = window.innerHeight ;
            var width = window.innerWidth;
            $('.person').height(height*0.95);
            $('.person').width(width);
            return this;    
        },
  
    
        });           
        return PersonView;
    });    