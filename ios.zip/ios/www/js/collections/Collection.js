define([
    'jquery',
    'underscore',
    'backbone',
    'models/ItemModel'
], function($, _, Backbone, mapModel){
    var mapCollection = Backbone.Collection.extend({
        initialize: function(){
        },
        model: mapModel,
        url: 'js/services/places.json',
    });
 
    return mapCollection;
});