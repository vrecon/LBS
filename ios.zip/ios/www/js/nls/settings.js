define({
    "root": {
        "Onderwijs": [
                    {"id":1,"name": "Sport"},
                    {"id":2,"name": "Kinderopvang"},
                    {"id":3,"name": "Scholen"},
                    {"id":4,"name": "Welzijn"},
                ],
        "Senioren":  [
                    {"id":1,"name": "Sportaanbieders"},
                    {"id":2,"name": "Woningbouw Corporaties"},
                    {"id":3,"name": "Institutionele Woningbezitters"},
                    {"id":4,"name": "AWBZ aanbieders"},
                    {"id":5,"name": "Welzijn"}
                ],   
        
        "Zorg":  [
                    {"id":1,"name": "Sportaanbieders"},
                    {"id":2,"name": "Zorginstellingen"},
                    {"id":3,"name": "GGD"},
                    {"id":4,"name": "AWBZ aanbieders"}
                ],   
         "Buurt":  [
                    {"id":1,"name": "Sportaanbieders"},
                    {"id":2,"name": "Jeugdwerk"},
                    {"id":3,"name": "Buurtvereniging"},
                    {"id":4,"name": "Welzijn"}
                ]
     }
});        